let sum = 0
let cardEl = document.getElementById("card-el")
let sumEl = document.getElementById("sum-el")
let cards = []
let hasBlackjack = false
let isAlive = false
let messageEl = document.getElementById("message-el")
cardEl.textContent = "Cards: "

sumEl.textContent = "Sum: "
messageEl.textContent = " "
function getRandomCard() {
    let dice = Math.floor(Math.random() * 13 ) + 1
    if(dice === 1){
        return 11
    }else if(dice > 10){
        return 10
    }else{
        return dice
    }

}
function startGame() {
    isAlive = true
    hasBlackjack = false
    let card1 = getRandomCard()
    let card2 = getRandomCard()
    cards = [card1,card2]
    sum = card1 + card2
    cardEl.textContent = "Cards: "

    renderGame()
}
    function renderGame(){
            for(i=0; i < cards.length; i++){
        cardEl.textContent += cards[i] + " "}
        
    sumEl.textContent = "Sum: " + sum
        if(sum === 21){
            messageEl.textContent = "You got blackjack"
            hasBlackjack = true
        }else if(sum < 21){
            messageEl.textContent = "New card?"
        }else {messageEl.textContent = "You lost"
        isAlive = false}
    }
    function newCard(){
        if(isAlive === true && hasBlackjack === false){
            let newCard = getRandomCard()
            cards.push(newCard)
            sum += newCard
            renderGame()
        }
    }