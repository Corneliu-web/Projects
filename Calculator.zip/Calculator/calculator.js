document.getElementById("num-1")
document.getElementById("num-2")
let som = document.getElementById("sum")
function add(){
    let result = num1 + num2
    som.textContent = "sum:" + result
}